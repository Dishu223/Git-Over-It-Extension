var e=e=>({cpp:`cpp`,java:`java`,python:`py`,python3:`py`,c:`c`,csharp:`cs`,javascript:`js`,typescript:`ts`,rust:`rs`,golang:`go`})[e]||`txt`,t=e=>{let t=new TextEncoder().encode(e),n=``;for(let e=0;e<t.byteLength;e++)n+=String.fromCharCode(t[e]);return btoa(n)};chrome.runtime.onMessage.addListener((e,t,n)=>(e.type===`SUBMISSION_ACCEPTED`&&(console.log(`Git Over It: Background Worker received submission!`,e.payload),r(e.payload,t.tab?.id),n({status:`processing`})),!0));async function n(e){console.log(`Git Over It: Contacting AI Backend Proxy...`),await new Promise(e=>setTimeout(e,1500));let t=`O(N)`,n=`O(N)`;e.tags?.includes(`Dynamic Programming`)?(t=`O(N^2)`,n=`O(N)`):e.tags?.includes(`Binary Search`)||e.tags?.includes(`Tree`)?(t=`O(log N) or O(N log N)`,n=`O(log N)`):(e.tags?.includes(`Two Pointers`)||e.tags?.includes(`Sliding Window`))&&(t=`O(N)`,n=`O(1)`);let r=e.tags?.length>0?e.tags.map(e=>`\`${e}\``).join(` `):"`Algorithm`";return`
# ${e.problemName.split(`-`).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(` `)}

> **Difficulty:** ${e.difficulty||`Medium`}
> **Topics:** ${r}
> **Language:** \`${e.language}\`

## 🧠 AI Analysis & Rules Engine

### Complexity
- **Time Complexity:** \`${t}\`
- **Space Complexity:** \`${n}\`

### Spaced Repetition (Active Recall)
To master this problem, it's recommended to review it again on:
- **1st Review:** ${new Date(Date.now()+1440*60*1e3).toDateString()}
- **2nd Review:** ${new Date(Date.now()+10080*60*1e3).toDateString()}
- **3rd Review:** ${new Date(Date.now()+720*60*60*1e3).toDateString()}

---

## 📝 Problem Description

<details>
<summary>Click to view</summary>

${e.description||`Description not available.`}

</details>

<br />
<hr />
<p align="right"><i>Generated automatically by Git Over It AI Engine</i></p>
`.trim()}async function r(r,i){try{let a=await chrome.storage.local.get([`github_pat`,`folderStructure`,`github_repo`]),o=a.github_pat,s=a.folderStructure||`flat`,c=a.github_repo||`Git-Over-It`;if(!o){console.error(`Git Over It: No GitHub Token found! Cannot push.`);return}let l=(await(await fetch(`https://api.github.com/user`,{headers:{Authorization:`token ${o}`}})).json()).login,u=r.difficulty||`Medium`,d=r.tags?.[0]?.replace(/\s+/g,``)||`Uncategorized`,f=``;s===`template_a`?f=`LeetCode/${d}/${u}/`:s===`template_b`?f=`LeetCode/${r.language}/${u}/`:s===`template_c`?f=`LeetCode/${u}/`:s!==`flat`&&(f=`solutions/`);let p=e(r.language),m=`${f}${r.problemName}`,h=`${m}/solution.${p}`,g=`${m}/README.md`,_=`Solved LeetCode : ${r.problemName.split(`-`).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(` `)} (with AI Analysis)`,v=await n(r),y=[{path:h,content:r.code},{path:g,content:v}],b=!0;for(let e of y){let n;try{let t=await fetch(`https://api.github.com/repos/${l}/${c}/contents/${e.path}`,{headers:{Authorization:`token ${o}`}});t.ok&&(n=(await t.json()).sha)}catch{}console.log(`Git Over It: Pushing ${e.path} to GitHub...`);let r={message:_,content:t(e.content)};n&&(r.sha=n);let i=await fetch(`https://api.github.com/repos/${l}/${c}/contents/${e.path}`,{method:`PUT`,headers:{Authorization:`token ${o}`,"Content-Type":`application/json`},body:JSON.stringify(r)});if(!i.ok){b=!1;let t=await i.json();console.error(`Git Over It: Push failed for`,e.path,t)}}if(b){console.log(`Git Over It: 🎉 Successfully pushed to GitHub!`);let e=await chrome.storage.local.get([`pushedCount`,`contributionHistory`]),t=(e.pushedCount||0)+1,n=e.contributionHistory||{},a=new Date,o=`${a.getFullYear()}-${String(a.getMonth()+1).padStart(2,`0`)}-${String(a.getDate()).padStart(2,`0`)}`;n[o]=(n[o]||0)+1,await chrome.storage.local.set({pushedCount:t,contributionHistory:n}),i&&chrome.tabs.sendMessage(i,{type:`PUSH_SUCCESS`,problem:r.problemName})}else console.error(`Git Over It: Push failed for one or more files.`)}catch(e){console.error(`Git Over It: Background push error`,e)}}